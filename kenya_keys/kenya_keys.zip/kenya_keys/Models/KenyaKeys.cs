﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Mono.Data.Sqlite;

namespace KK
{
    public class SqliteBase
    {
        public string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["KKDB"].ToString();
        
        public List<string> columns { get; set; }
        public string key { get; set; } 
        public string table { get; set; }
        
        private string _query;
        public string query { get  { return this._query; } }


        private SqliteConnection conn;
        private SqliteCommand cmd;
        private SqliteDataReader reader;
        
        public SqliteBase() {
            this.key = null;
            this.columns = new List<string>();
           
        }
        
       
        
        
        
        private void loadParameters() {
           
        }

    }
    

    
}
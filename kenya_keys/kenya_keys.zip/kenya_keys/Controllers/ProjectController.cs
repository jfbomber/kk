﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KK;
using KK.Models;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.IO;

namespace KK.Controllers
{
    public class ProjectController : Controller
    {
        public ActionResult Edit(int? project_id = null)
        {
            if (project_id != null)
            {
                KK.Models.Project project = Project.GetById(Convert.ToInt32(project_id));
                this.ViewData["Project"] = project;
            }
            return PartialView();
        }

        public ActionResult Index()
        {
            this.ViewData["Projects"] = Project.GetAll();
            return PartialView("Index");
        }

        public ActionResult List()
        {
            this.ViewData["Projects"] = Project.GetAll();
            return PartialView("List");
        }

        public ActionResult Show(int projectId)
        {
            this.ViewData["project"] = Project.GetById(projectId);
            return PartialView("Show");
        }

        [HttpPost]
        public ContentResult Save(int? project_id, string proj_name, bool? proj_display, int? photo_id, string proj_html)
        {
            Session.Remove("temp_image_data");
            Project project = new Project();
            if (project_id != null)
            {
                project = Project.GetById(Convert.ToInt32(project_id));
            }
            project.ProjectName = proj_name;
            project.ProjectHtml = proj_html;
            project.ProjectHide = proj_display == null ? false : Convert.ToBoolean(proj_display);
            if (photo_id != null) {
                project.ProjectImageID = Convert.ToInt32(photo_id);
            }
            
            project.Save();
            string result = string.Format("{{ result : 'success', data : {{ project_id :{0} }}", project.ProjectID);
            return new ContentResult { Content = result };  ;
        }

        [HttpGet]
        public ContentResult Delete(int projectID)
        {
            Project.Delete(projectID);
            string result = string.Format("{{ result : 'success', data : {{ project_id :{0} }}", projectID);
            return new ContentResult { Content = result }; ;
        }


        

       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KK.Models;
using System.Windows;
using System.Windows.Input;
namespace KK.Controllers
{
    public class PhotoController : Controller
    {
        //
        // GET: /Photo/



        [HttpGet]
        public ContentResult Last()
        {
            if (Session["temp_image"] != null)
            {
                Photo photo = (Photo)Session["temp_image"];
                Session.Remove("temp_image");
                return new ContentResult { Content = string.Format("{{\"photo_id\":{0},\"photo_name\":\"{1}\"}}", photo.PhotoID, photo.PhotoName) }; 
            }
            return null;
        }

        [HttpPost]
        public JsonResult Add(HttpPostedFileBase upload, bool storeRaw = false, string redirect = "")
        {
            // 
            Photo photo = new Photo(upload, storeRaw);
            photo.Save();
            Session["temp_image"] = photo;

            if (redirect.Length > 0)
            {
                Response.Redirect("~/Admin/Index");
            }
            return Json(photo); 
        }

        public JsonResult Delete(int photoID)
        {
            Photo photo = Photo.Get(photoID);
            Photo.Delete(photoID);
            return Json(photo);
        }

        public ActionResult GetPhoto(int photoId, string size = "t")
        {
           byte[] imgdata = Photo.GetPhotoData(photoId, size);
            if (imgdata == null) {
                System.Drawing.Image img = System.Drawing.Image.FromFile(Server.MapPath("~/images/graphics/image-not-found.jpg"));
                imgdata = Photo.ConvertImageToByteArray(img);
            }
            return new FileContentResult(imgdata, "image/jpeg");
        }

        public ActionResult List()
        {
            ViewData["photos"] = Photo.GetAll();
            return PartialView("List");
        }


        public ActionResult DropDown(string onchange = "alert(this.options[this.selectedIndex].value)")
        {
            PhotoDropDown photos = new PhotoDropDown();
            photos.OnChange = onchange;
            return PartialView(photos);
        }
    }
}
